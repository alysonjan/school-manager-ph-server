const o={appName:"SchoolMANAGER"};export{o as C};
